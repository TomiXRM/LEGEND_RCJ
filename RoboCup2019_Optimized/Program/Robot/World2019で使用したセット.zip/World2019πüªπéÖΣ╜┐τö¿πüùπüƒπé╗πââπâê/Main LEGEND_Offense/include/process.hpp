#include "LGUI.h"
extern LGUI ui;

void wrap_setup(){
        ui.Entry('O',DONOTHING,DONOTHING,DONOTHING);
}
